package fr.uge.manifest;

public record Passenger(String destination) implements Cargo{
	public Passenger{}
	
	@Override
	public int price() {
		return 10;
	}
	
	@Override
	public String toString() {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(destination);
		stringBuilder.append(" (passenger)");
		return stringBuilder.toString();
	}
}
