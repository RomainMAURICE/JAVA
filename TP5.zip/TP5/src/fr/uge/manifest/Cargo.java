package fr.uge.manifest;

public interface Cargo {
	public abstract int price();
}
