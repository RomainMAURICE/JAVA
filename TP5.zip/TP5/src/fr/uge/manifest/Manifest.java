package fr.uge.manifest;

import java.util.ArrayList;

public class Manifest {
	private ArrayList<Object> containers;
	
	public Manifest() {
		containers = new ArrayList<>();
	}
		
	public void add(Object objet) {
		containers.add(objet);
	}
	
	

	
	
	@Override
	public String toString() {
		StringBuilder stringBuilder = new StringBuilder();
		int i=1;
		for(var container : containers) {
			stringBuilder.append(i)
			  .append(". ")
			  .append(container)
			  .append("\n");
			  i++;
		}
		return stringBuilder.toString();
	}
}
